# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['auth_package', 'auth_package.libs', 'auth_package.libs.auth_client']

package_data = \
{'': ['*']}

install_requires = \
['Jinja2>=2.11.2,<3.0.0',
 'aiofiles>=0.6.0,<0.7.0',
 'fastapi>=0.63.0,<0.64.0',
 'msal>=1.8.0,<2.0.0',
 'pymongo>=3.11.2,<4.0.0',
 'uvicorn>=0.13.2,<0.14.0']

setup_kwargs = {
    'name': 'auth-package',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'InnerTaste',
    'author_email': 'sugantric@yahoo.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
